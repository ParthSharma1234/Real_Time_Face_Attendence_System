from django.shortcuts import render
from .firebase_config import get_db

def dashboard(request):
    db = get_db()

    # 🔴 IMPORTANT: Firebase node name is CASE-SENSITIVE
    students_ref = db.reference('Students')  # not 'students'
    students = students_ref.get() or {}

    total_students = len(students)

    # Firebase uses: standing = 'A' (Absent) / 'P' (Present)
    present = sum(1 for s in students.values() if s.get('standing') == 'P')
    absent = sum(1 for s in students.values() if s.get('standing') == 'A')

    # Chart data
    chart_labels = []
    chart_values = []

    for s in students.values():
        chart_labels.append(s.get('name', 'Unknown'))
        chart_values.append(s.get('total_attendance', 0))

    context = {
        'students': students,
        'total_students': total_students,
        'present': present,
        'absent': absent,
        'chart_labels': chart_labels,
        'chart_values': chart_values
    }

    return render(request, 'dashboard.html', context)