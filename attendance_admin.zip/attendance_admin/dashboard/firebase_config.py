import firebase_admin
from firebase_admin import credentials, db

cred = credentials.Certificate("serviceAccountKey.json")

if not firebase_admin._apps:
    firebase_admin.initialize_app(cred, {
        'databaseURL': "https://faceattendencerealtime-8a7a2-default-rtdb.firebaseio.com/Students"
    })

def get_db():
    return db
